globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3b11450fb0b412d9.js",
    "static/chunks/adf1838ed8174570.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/30ea11065999f7ac.js",
    "static/chunks/d49106d007e3bd3d.js",
    "static/chunks/turbopack-f2ab7b5884a9787c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];