module.exports=[85296,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_login_forgot-password_page_actions_4864805c.js.map