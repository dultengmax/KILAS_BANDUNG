module.exports=[70858,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tentang_page_actions_0f8d0dd6.js.map