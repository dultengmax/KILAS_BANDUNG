module.exports=[66962,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_article_route_actions_f6478604.js.map