var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/article/route.js")
R.c("server/chunks/node_modules_next_0ba98f73._.js")
R.c("server/chunks/node_modules_zod_v4_dead09ad._.js")
R.c("server/chunks/[root-of-the-server]__61b3e1f2._.js")
R.c("server/chunks/_next-internal_server_app_api_article_route_actions_f6478604.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/article/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/article/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
