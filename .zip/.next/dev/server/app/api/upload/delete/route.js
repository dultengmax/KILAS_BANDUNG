var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/delete/route.js")
R.c("server/chunks/node_modules_next_6fe14deb._.js")
R.c("server/chunks/[root-of-the-server]__0763c875._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_delete_route_actions_0823967f.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/upload/delete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/upload/delete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
