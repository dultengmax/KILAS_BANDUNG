module.exports = [
"[project]/lib/action/article.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/lib/action/article.ts [app-route] (ecmascript)");
    });
});
}),
];