module.exports = [
"[project]/app/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_loading_tsx_b05711b0._.js.map