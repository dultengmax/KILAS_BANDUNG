module.exports = [
"[project]/app/cari/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_cari_loading_tsx_4f4cac6d._.js.map