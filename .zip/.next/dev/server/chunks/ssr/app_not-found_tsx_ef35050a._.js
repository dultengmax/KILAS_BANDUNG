module.exports = [
"[project]/app/not-found.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_not-found_tsx_ef35050a._.js.map