globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b82d6d8034ed5191.js",
    "static/chunks/bd4ab1517efdc1c3.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/4451e45b511cb734.js",
    "static/chunks/turbopack-1f524e25a9e6ce53.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];