module.exports=[60723,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload_delete_route_actions_0823967f.js.map