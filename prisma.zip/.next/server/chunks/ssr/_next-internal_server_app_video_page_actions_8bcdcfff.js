module.exports=[6666,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_video_page_actions_8bcdcfff.js.map