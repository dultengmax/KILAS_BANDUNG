module.exports=[70604,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_privacy-policy_page_actions_74da7ed0.js.map