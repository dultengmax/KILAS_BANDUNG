module.exports=[61033,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_cari_loading_tsx_4f4cac6d._.js.map