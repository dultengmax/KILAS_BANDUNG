var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/delete/route.js")
R.c("server/chunks/[root-of-the-server]__43a81309._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_delete_route_actions_0823967f.js")
R.m(53601)
module.exports=R.m(53601).exports
