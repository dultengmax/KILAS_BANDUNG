var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/article/route.js")
R.c("server/chunks/[root-of-the-server]__ee98de67._.js")
R.c("server/chunks/_9744b1a2._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_article_route_actions_f6478604.js")
R.m(99079)
module.exports=R.m(99079).exports
