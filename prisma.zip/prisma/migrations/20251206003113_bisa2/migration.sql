-- AlterTable
ALTER TABLE "Article" ALTER COLUMN "author" DROP NOT NULL;
