-- AlterTable
ALTER TABLE "AboutUs" ADD COLUMN     "email" TEXT,
ADD COLUMN     "misi" TEXT,
ADD COLUMN     "visi" TEXT;
